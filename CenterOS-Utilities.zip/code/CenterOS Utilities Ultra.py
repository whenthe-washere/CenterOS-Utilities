import os
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog
from PIL import Image, ImageTk
import json

print("CenterOS Utilities Ultra")
print("       _______           _______    ____  ____")
print("|    |    |    | |     |    |    | |     |____")
print("|    |    |    | |     |    |    | |----      |")
print("|____|    |    | |____ |    |    | |____  ____|")
print("")
print("                            _________________    ________     ________")
print("   |        |   |                   |           |        |   |        |")
print("   |        |   |                   |           |        |   |        |")
print("   |        |   |                   |           |        |   |        |")
print("   |        |   |                   |           |________|   |________|")
print("   |        |   |                   |           |       |    |        |")
print("   |        |   |                   |           |       |    |        |")
print("   |        |   |                   |           |        |   |        |")
print("   |________|   |________           |           |        |   |        |")

# JSON file to store additional tabs
ADDITIONAL_TABS_FILE = "additional_tabs.json"

def save_additional_tabs(tabs):
    """Saves the additional tabs to a file."""
    with open(ADDITIONAL_TABS_FILE, "w") as file:
        json.dump(tabs, file)

def load_additional_tabs():
    """Loads the additional tabs from the file."""
    if os.path.exists(ADDITIONAL_TABS_FILE):
        with open(ADDITIONAL_TABS_FILE, "r") as file:
            return json.load(file)
    return []

def list_apps_and_files(directory):
    try:
        return os.listdir(directory)
    except FileNotFoundError:
        return []

def get_icon_path(app_name, directory):
    possible_icon_extensions = ['.png', '.ico']
    for ext in possible_icon_extensions:
        icon_path = os.path.join(directory, app_name + ext)
        if os.path.exists(icon_path):
            return icon_path
    return None

def open_app_or_file(path):
    try:
        os.startfile(path)
    except Exception as e:
        messagebox.showerror("Error", f"Unable to open: {e}")

def create_app_list(frame, items, directory):
    listbox = tk.Listbox(frame)
    listbox.pack(side="left", fill="both", expand=True)

    scrollbar = tk.Scrollbar(frame, orient="vertical")
    scrollbar.config(command=listbox.yview)
    scrollbar.pack(side="right", fill="y")

    listbox.config(yscrollcommand=scrollbar.set)

    # Keep a reference to images to prevent garbage collection
    image_refs = []

    for item in items:
        item_path = os.path.join(directory, item)
        icon_path = get_icon_path(item, item_path)

        if icon_path:
            image = Image.open(icon_path)
            image = image.resize((32, 32), Image.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            image_refs.append(photo)  # Keep a reference
            listbox.insert(tk.END, item)
            listbox.itemconfig(tk.END, {'image': photo})
        else:
            listbox.insert(tk.END, item)

    listbox.bind("<Double-Button-1>", lambda event: open_app_or_file(os.path.join(directory, listbox.get(tk.ACTIVE))))

def add_new_tab(notebook, tabs, directory=None):
    """Adds a new tab with a directory specified by the user."""
    if not directory:
        directory = filedialog.askdirectory(title="Select Folder")
        if not directory:
            return  # User canceled the folder selection

    # Create a new frame for the tab
    new_frame = ttk.Frame(notebook)
    notebook.add(new_frame, text=os.path.basename(directory))  # Show only the folder name

    # List apps and files in the directory
    items = list_apps_and_files(directory)
    create_app_list(new_frame, items, directory)

    # Save the new tab path
    if directory not in tabs:  # Prevent duplicate entries
        tabs.append(directory)
        save_additional_tabs(tabs)

def create_shortcuts_tab(notebook, shortcuts):
    """Creates the Shortcuts tab."""
    frame = ttk.Frame(notebook)
    notebook.add(frame, text="Shortcuts")
    listbox = tk.Listbox(frame)
    listbox.pack(side="left", fill="both", expand=True)
    scrollbar = tk.Scrollbar(frame, orient="vertical")
    scrollbar.config(command=listbox.yview)
    scrollbar.pack(side="right", fill="y")
    listbox.config(yscrollcommand=scrollbar.set)

    for shortcut_name, shortcut_path in shortcuts:
        listbox.insert(tk.END, shortcut_name)

    listbox.bind("<Double-Button-1>", lambda event: open_app_or_file(shortcuts[listbox.curselection()[0]][1]))

def main():
    # Fixed directories for system apps
    system_dir = "C:\\Windows\\System32"
    store_dir = "C:\\Program Files\\WindowsApps"

    # Load additional tabs and shortcuts
    additional_tabs = load_additional_tabs()

    # Create the main Tkinter window
    global root
    root = tk.Tk()
    root.title("CenterOS Utilities")
    root.geometry("800x600")

    # Create the notebook (tabbed interface)
    notebook = ttk.Notebook(root)
    notebook.pack(expand=True, fill="both")

    # Create the fixed tabs
    system_frame = ttk.Frame(notebook)
    store_frame = ttk.Frame(notebook)
    notebook.add(system_frame, text="System32")
    notebook.add(store_frame, text="Microsoft Store")

    # List apps and files in the fixed directories
    create_app_list(system_frame, list_apps_and_files(system_dir), system_dir)
    create_app_list(store_frame, list_apps_and_files(store_dir), store_dir)

    # Create the Shortcuts tab
    shortcuts = [("Notepad", "C:\\Windows\\notepad.exe"), ("Calculator", "C:\\Windows\\System32\\calc.exe")]
    create_shortcuts_tab(notebook, shortcuts)

    # Add any additional tabs from previous session
    for tab in additional_tabs:
        add_new_tab(notebook, additional_tabs, tab)

    # Add a button to open new tabs for user-specified directories
    button_frame = ttk.Frame(root)
    button_frame.pack(fill="x", side="bottom")
    ttk.Button(button_frame, text="Open New Tab", command=lambda: add_new_tab(notebook, additional_tabs)).pack()

    root.mainloop()

if __name__ == "__main__":
    main()